# Paper #3 Protocol: Sheaf-Theoretic Explanation for Phase-Structured Dynamics

**Projekt:** Transformers as Implicit Sheaf Networks
**Start:** 2026-01-04
**Status:** ACTIVE RESEARCH
**Autor:** Davide D'Elia

---

## Vorgänger-Papers

| # | Titel | DOI | Status |
|---|-------|-----|--------|
| 1 | Uniformity Asymmetry | 10.5281/zenodo.18110161 | Published 2025-12-31 |
| 2 | Phase-Structured Dynamics | 10.5281/zenodo.18142454 | Published 2026-01-04 |
| 3 | Sheaf-Theoretic Explanation | — | **IN PROGRESS** |

---

## Chronologisches Protokoll

### 2026-01-04 | Tag 1: Die Sheaf-Hypothese

#### 14:00 - Initialzündung

**Kontext:** Paper #2 gerade auf Zenodo publiziert. GitHub Release v2.0 erstellt.

**Die Frage:** Warum invertiert die Embedding-Output-Korrelation in späten Layern?

**Grok's Input:** Verweis auf Sheaf Neural Networks (Bodnar et al., NeurIPS 2022) als mögliche Erklärung.

**Erste Hypothese:**
> Transformers sind implizite Sheaf-Netzwerke. Das Gluing Axiom erzwingt die Inversion.

#### 15:00 - Literatur-Review

**Recherchierte Papers:**
1. Bodnar et al. (2022) - "Neural Sheaf Diffusion" (NeurIPS)
2. Hansen & Ghrist (2019) - "Toward a Spectral Theory of Cellular Sheaves"
3. Ayzenberg & Magai (2025) - "Sheaf Theory: From Deep Geometry to Deep Learning"
4. "Self-Attention as Parametric Endofunctor" (arXiv:2501.02931)

**Kern-Einsichten:**
- Sheaves = Vektor-Räume auf Graphen mit linearen "Restriction Maps"
- Sheaf Laplacian L_F = delta^T delta misst Inkonsistenz
- Gluing Axiom: Lokale Daten die übereinstimmen -> globale Section
- GNNs mit trivialer Sheaf (rho = I) sind limitiert
- Nicht-triviale Sheaves ermöglichen bessere Heterophilie-Behandlung

**Key Quote (Bodnar):**
> "Discretised parametric diffusion processes have greater control over asymptotic behaviour when the sheaf is non-trivial."

#### 16:00 - Code-Analyse (Bodnar GitHub)

**Repository:** twitter-research/neural-sheaf-diffusion

**Analysierte Dateien:**
- `lib/laplace.py` - Sheaf Laplacian Konstruktion
- `models/sheaf_base.py` - Basis-Diffusionsklasse
- `models/sheaf_models.py` - SheafLearner Implementierungen
- `models/laplacian_builders.py` - Laplacian Builder

**Technische Einsichten:**
- Block-Diagonale Struktur des Laplacian
- Attention-ähnliche Mechanismen für Restriction Map Learning
- Normalisierte vs. unnormalisierte Laplacians

#### 17:00 - Paper #3 Outline Erstellung

**Erstellte Datei:** `PAPER_3_OUTLINE.md`

**Struktur:**
1. Introduction (Motivation, Claims)
2. Background (Sheaves, Sheaf NNs, Categorical Attention)
3. Main Result (Transformers as Sheaf Networks)
4. Theorem (Gluing -> Inversion)
5. Empirical Validation
6. Discussion

#### 18:00 - Gemini's mathematische Formalisierung

**Input von Gemini:** Rigorose Formalisierung von Section 3.1 und 3.2

**Neue Definitionen:**
- Definition 3.3 (Underlying Topology): Complete Graph K_N
- Definition 3.4 (Transformer Sheaf): Stalks, Interaction Spaces, Restriction Maps
- Proposition 3.1 (Attention = Restriction Maps): rho_{ij} = sqrt(A_{ij}) * W_V
- Definition 3.5 (Coboundary Operator)
- Definition 3.6 (Sheaf Laplacian): Explizite Blockmatrix-Formel

**Schlüssel-Insight:**
> Standard GNNs: skalares Mixing (A_{ij} in R)
> Transformers: Vektor-Transport (rho_{ij} in R^{d x d_v})
>
> W_V TRANSFORMIERT Daten, nicht nur mischen. Das erklärt Transformer-Expressivität.

#### 19:00 - Theorem 4.1 Beweis-Skizze

**Erstellte Datei:** `THEOREM_4_1_PROOF_SKETCH.md`

**Beweis-Struktur:**
- 4 Annahmen (A1-A4)
- 3 Lemmas:
  - Lemma 4.1: Geometrie-Erhaltung in frühen Layern
  - Lemma 4.2: Gluing Axiom erzwingt Konvergenz
  - Lemma 4.3: Geometrische Inversion existiert
- Hauptbeweis via Zwischenwertsatz

**Der Kern-Insight (formalisiert):**
```
Annahme A1 (Input):    d^(0)(A_i, A_j) < d^(0)(A_i, B_i)
Annahme A2 (Output):   d^(L)(A_i, B_i) -> minimal
                       ─────────────────────────────
Konsequenz:            Geometrie MUSS invertieren
```

#### 20:00 - Gemini Deep Research Prompt

**Erstellte Datei:** `GEMINI_DEEP_RESEARCH_PROMPT.md`

**7 Forschungsfragen:**
1. Literatur-Review (existierende Sheaf-Transformer Arbeiten?)
2. Mathematische Validierung (Formalisierung korrekt?)
3. Spektraltheorie (L* aus Spektrum ablesen?)
4. Beweis-Stärkung (zusätzliche Annahmen?)
5. Empirische Predictions (Falsifizierbarkeit?)
6. Architektur-Implikationen (Sheaf-aware Transformers?)
7. Grenzfälle (Warum Gemma-2B kein L*?)

**Status:** ~~Gesendet, warte auf Ergebnisse.~~ **ERGEBNISSE ERHALTEN!**

#### 21:00 - BREAKTHROUGH: Gemini Deep Research Ergebnisse

**Erstellte Datei:** `GEMINI_RESEARCH_RESULTS.md`

**Titel des Reports:** "Topologische Mechanik großer Sprachmodelle: Ein garbentheoretischer Rahmen für Transformerdynamik und Einbettungsgeometrie"

**DREI ZENTRALE DURCHBRÜCHE:**

**1. Spektrale Erklärung der Uniformity Asymmetry:**
> "Die beobachtete Asymmetrie ist kein Artefakt, sondern die direkte Konsequenz der **nicht-trivialen Holonomie** in semantischen Garben."

- Semantische Äquivalenz → harmonische 0-Formen
- Geometrie diktiert durch Eigenvektoren des Garben-Laplace
- Asymmetrie = geometrische Projektion der Restriction-Map-Asymmetrie

**2. Beweis des Inversions-Theorems via Hodge-Theorie:**
> "L* ist der Punkt des **kohomologischen Phasenübergangs**."

| Phase | Layer | Dynamik |
|-------|-------|---------|
| Konsens | l < L* | Minimiert Garben-Dirichlet-Energie (Glättung) |
| Singularität | l ≈ L* | H¹(G; F) ≠ 0 (Obstruktion) |
| Inversion | l > L* | Inverse Diffusion (Schärfung) |

**Die Formel:**
```
Unterhalb L*: x_{l+1} ≈ x_l - γ∇E(x)  → Energie-Minimierung
Oberhalb L*:  x_{l+1} ≈ x_l + γ∇E(x)  → Energie-Maximierung
```

**3. Architektonische Gauge-Theorie (erklärt Gemma-2B!):**
> "Normalisierungsschichten wirken als **Eichtransformationen (Gauge Fixing)**."

| Architektur | Norm | Effekt |
|-------------|------|--------|
| Pythia | LayerNorm | Radiale Freiheitsgrade → klare Inversion |
| Gemma | RMSNorm | Sphärische Geometrie → subtile/keine Inversion |

**Zusätzliche Validierungen:**
- ✅ √(A_{ij}) ist **mathematisch notwendig** für spektrale Stabilität
- ✅ Attention = Garben-Diffusion formal bestätigt
- ✅ RoPE = "Flacher Zusammenhang" (vorinstallierte Topologie)
- ✅ GeGLU = "Kohomologisches Schalten" (dynamische Topologie-Änderung)

**Neue empirische Predictions:**
1. Maps kontrahierend (l < L*) vs. expansiv (l > L*)
2. Anisotropie-Profil = Bell Curve mit Maximum bei L*
3. Pythia: starke Bell Curve vs. Gemma: flaches Profil

---

## Hypothesen-Log (AKTUALISIERT nach Gemini Research)

### H1: Transformers sind implizite Sheaf Networks
**Status:** ✅ **VALIDIERT**
**Evidenz:** Gemini bestätigt: "Transformer-Garbe F_T ist ein dynamisches System"
**Neue Einsicht:** Attention = Operator der Garben-Diffusionsgleichung löst

### H2: Attention definiert dynamische Restriction Maps
**Status:** ✅ **VALIDIERT + ERKLÄRT**
**Formel:** ρ_{ij} = √(A_{ij}) · W_V
**Validierung:** "Die Wurzel √(A_{ij}) ist mathematisch notwendig für Symmetrie des Energie-Funktionals"
**Referenz:** Entspricht Sinkhorn-Knopp-Normalisierung

### H3: Gluing Axiom erzwingt Late-Layer Inversion
**Status:** ✅ **BEWEIS GESTÄRKT via Hodge-Theorie**
**Neuer Beweis-Ansatz:**
- Hodge-Zerlegung: C⁰(G; F) = ker(Δ) ⊕ im(δᵀ)
- L* = kohomologischer Phasenübergang
- H¹(G; F) ≠ 0 als Obstruktion

### H4: L* ist aus Sheaf-Laplacian-Spektrum ablesbar
**Status:** ⏳ **THEORETISCH FUNDIERT, EMPIRISCH UNGETESTET**
**Neue Prediction:** Spektraler Gap λ₂ markiert semantische Domänentrennung
**Tabelle:** Eigenwert-Regime ↔ LLM-Phänomene etabliert

### H5: Gemma-2B zeigt keine klare Inversion
**Status:** ✅ **ERKLÄRT durch Gauge-Theorie**
**Mechanismus:** RMSNorm = striktes Gauge-Fixing
- Projiziert auf Hypersphäre S^{d-1}
- Nur Winkel-Diffusion möglich (Connection Laplacian)
- Verhindert Representation Collapse, macht Inversion subtiler
**Zusatz:** RoPE + GeGLU verstärken diesen Effekt

### H6: (NEU) Anisotropie folgt Bell Curve
**Status:** 🆕 **NEUE PREDICTION**
**Vorhersage:** Anisotropie-Profil hat Maximum bei L*
**Unterschied:** Pythia (stark) vs. Gemma (flach)

---

## Offene Fragen (AKTUALISIERT)

### Priorität 1 (Blocking) - GELÖST ✅
- [x] Ist die mathematische Formalisierung korrekt? → **JA, validiert**
- [x] Gibt es existierende Sheaf-Transformer Literatur? → **JA: Gardner, Ayzenberg et al.**

### Priorität 2 (Wichtig) - TEILWEISE GELÖST
- [x] Welche Rolle spielt FFN? → **Quellterm in Diffusionsgleichung**
- [ ] Wie integriert man Multi-Head Attention? → **Summe über Köpfe? Noch zu formalisieren**
- [ ] Kann man Restriction Maps empirisch extrahieren? → **Methodik bekannt, noch nicht implementiert**

### Priorität 3 (Empirische Validierung) - NEU PRIORISIERT
- [ ] Anisotropie-Profil messen (Bell Curve Prediction)
- [ ] Restriction Maps aus Pythia extrahieren
- [ ] Spektral-Analyse bei L* durchführen
- [ ] Pythia vs. Gemma Vergleich

### Priorität 4 (Paper Writing)
- [ ] Hodge-Theorie Beweis ausformulieren
- [ ] Spektrale Regime-Tabelle integrieren
- [ ] Gauge-Theorie Section schreiben

---

## Nächste Schritte (AKTUALISIERT)

### Phase 1: Theorie-Konsolidierung (ABGESCHLOSSEN)
1. ~~Warte auf Gemini Deep Research~~ ✅ **ERHALTEN**
2. ✅ Ergebnisse integrieren → **DONE**
3. ✅ Theorem 4.1 Beweis mit Hodge-Theorie neu schreiben → **DONE**

### Phase 2: Empirische Validierung (IN PROGRESS)
4. ⏳ Anisotropie-Profil für Pythia messen → **NOTEBOOK ERSTELLT**
   - `notebooks/Anisotropy_Profile_Pythia.ipynb`
5. 🔬 Restriction Maps extrahieren (Methodik aus Gemini Report)
6. 🔬 Pythia vs. Gemma Vergleich

### Phase 3: Paper Draft
7. 📝 LaTeX Paper schreiben
8. 📝 Figures erstellen (Spektrale Regime, Anisotropie Bell Curve)
9. 📝 Target: NeurIPS 2026 oder ICLR 2027

---

## Ressourcen

### Dateien in diesem Ordner
```
paper3/
├── PAPER_3_PROTOCOL.md              # Dieses Dokument (Reise-Log)
├── PAPER_3_OUTLINE.md               # Paper-Struktur
├── THEOREM_4_1_PROOF_SKETCH.md      # Formaler Beweis (pre-Gemini, v1.0)
├── THEOREM_4_1_HODGE_PROOF.md       # Hodge-Beweis (v2.0)
├── GEMINI_DEEP_RESEARCH_PROMPT.md   # Research-Anfrage
├── GEMINI_RESEARCH_RESULTS.md       # BREAKTHROUGH Ergebnisse
└── notebooks/
    └── Anisotropy_Profile_Pythia.ipynb  # 🆕 Empirische Validierung
```

### Externe Referenzen
- Bodnar Code: github.com/twitter-research/neural-sheaf-diffusion
- Hansen & Ghrist: arXiv (Spectral Theory of Cellular Sheaves)
- Gardner: "Transformers are Sheaves"
- Ayzenberg et al.: "Sheaf Theory: From Deep Geometry to Deep Learning"
- Paper #1: doi.org/10.5281/zenodo.18110161
- Paper #2: doi.org/10.5281/zenodo.18142454

### Neue Literatur (aus Gemini Report)
- 125 Quellen referenziert in Gemini's Deep Research
- Key: Hodge-Theorie, Sinkhorn-Knopp-Normalisierung, Gauge-Theorie

---

## Meta-Reflexionen

### Was macht diese Forschung besonders?

1. **Empirisch -> Theoretisch:** Wir starten mit robusten Beobachtungen (4 Modell-Familien) und suchen die mathematische Erklärung.

2. **Cross-Disziplinär:** Verbindung von:
   - Algebraische Topologie (Sheaves)
   - Geometric Deep Learning (GNNs)
   - NLP/LLMs (Transformers)
   - Mechanistische Interpretability

3. **Falsifizierbar:** Die Theorie macht konkrete Predictions:
   - Spektral-Shift bei L*
   - Restriction Maps sollten extrahierbar sein
   - Sheaf-aware Transformers sollten Inversion kontrollieren können

### Risiken

1. **Mathematische Fehler:** Die Formalisierung könnte inkorrekt sein
2. **Overfit zur Empirie:** Die Theorie könnte nur post-hoc Erklärung sein
3. **Zu komplex:** Reviewer könnten Sheaf-Theorie als unnötig sehen
4. **Scooping:** Andere könnten ähnliche Ideen haben

### Warum trotzdem weitermachen?

> "Wenn es wirklich ein universeller Code ist, dann hat es isomorphe Pendants in anderen Bereichen."

Die Sheaf-Formulierung ist nicht willkürlich - sie ist die natürliche Sprache für "lokale Daten die global konsistent sein müssen". Genau das machen Transformers.

---

---

## Meilensteine

| Datum | Ereignis | Bedeutung |
|-------|----------|-----------|
| 2026-01-04 14:00 | Sheaf-Hypothese formuliert | Startpunkt |
| 2026-01-04 17:00 | Paper #3 Outline erstellt | Struktur |
| 2026-01-04 19:00 | Theorem 4.1 Beweis-Skizze v1.0 | Erster Beweis |
| 2026-01-04 21:00 | **GEMINI BREAKTHROUGH** | Validierung + Erweiterung |
| 2026-01-04 22:00 | Theorem 4.1 Hodge-Beweis v2.0 | **FORMALER BEWEIS** |

---

*Protokoll initialisiert: 2026-01-04*
*Letzte Aktualisierung: 2026-01-04 22:00*
*Status: THEORIE KOMPLETT - Phase 1 abgeschlossen, bereit für empirische Validierung*
